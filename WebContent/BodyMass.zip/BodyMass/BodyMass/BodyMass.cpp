// BodyMass.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream> 
#include <cmath> 
using namespace std;

int main(){
	const float METERS_CONVERT = 39.96;
	const float KILO_CONVERT = 2.2;
	int heightInches;
	int weightPounds;
	char activity;
	char gender;
	char run;

	cout << "BMI" << endl;
	cout << "Please enter your height in inches: ";

	bool valid_entry = false;
	while (!valid_entry) {

		while ((!(cin >> heightInches)) || ((heightInches < 50) || (heightInches > 88))) {
			cin.clear();
			cin.ignore(std::numeric_limits<streamsize>::max(), '\n');
			cout << "ERROR: Invalid Entry.  Try again.\n\n\nPlease enter a value greater than 50 and less than 88:  ";
			cin.clear();

		}

		valid_entry = true;

	}
	cout << "Please enter your weight in pounds:  ";

	valid_entry = false;
	while (!valid_entry) {

		while ((!(cin >> weightPounds)) || ((weightPounds < 70) || (weightPounds > 400))) {
			cin.clear();
			cin.ignore(std::numeric_limits<streamsize>::max(), '\n');
			cout << "ERROR: Invalid Entry.  Try again.\n\n\nPlease enter a value greater than 70 and less than 400:  ";
			cin.clear();

		}

		valid_entry = true;

	}
	cout << "Please enter your gender:  ";

	valid_entry = false;
	while (!valid_entry) {

		while ((!(cin >> gender)) || ((tolower(gender) != 'm') && (tolower(gender) != 'f'))) {
			cin.clear();
			cin.ignore(std::numeric_limits<streamsize>::max(), '\n');
			cout << "ERROR: Invalid Entry.  Try again.\n\n\nPlease enter a m for male or f for female:  ";
			cin.clear();

		}

		valid_entry = true;

	}
	cout << "Please enter if you're active or inactive:  ";

	valid_entry = false;
	while (!valid_entry) {

		while ((!(cin >> activity)) || ((tolower(activity) != 'i') && (tolower(activity) != 'a'))) {
			cin.clear();
			cin.ignore(std::numeric_limits<streamsize>::max(), '\n');
			cout << "ERROR: Invalid Entry.  Try again.\n\n\nPlease enter an i for inactive or an a for active:  ";
			cin.clear();

		}

		valid_entry = true;

	}
	float meters = heightInches / METERS_CONVERT;
	float kilograms = weightPounds / KILO_CONVERT;
	float BMI = kilograms / pow(meters, 2);

	if (BMI < 18.5){
		cout << "You are underweight" << endl;
	}
	else if (BMI >= 18.5 && BMI <= 25){
		cout << "You are at an optimal weight" << endl;
	}
	else{
		cout << "You are overweight" << endl;
	}
	if ((gender = 'f') && (activity = 'a')){
		float dailyCalories = weightPounds * 12;
	}
	else if ((gender = 'f') && (activity = 'i')){
		float dailyCalories = weightPounds * 10;
	}
	else if ((gender = 'm') && (activity = 'a')){
		float dailyCalories = weightPounds * 15;
	}
	else{
		float dailyCalories = weightPounds * 13;
		cout << "Your caloric intake should be:  " << dailyCalories << endl;
	}
		cout << "Your height in meters is:  " << meters << endl;
		cout << "Your weight in kilograms is:  " << kilograms << endl;
		cout << "Your BMI is:  " << BMI << endl;
		cout << "Do you want to run again? Yes or No?" << endl;
		valid_entry = false;
		while (!valid_entry) {

			while ((!(cin >> run)) || ((tolower(run) != 'y') && (tolower(run) != 'n'))) {
				cin.clear();
				cin.ignore(std::numeric_limits<streamsize>::max(), '\n');
				cout << "ERROR: Invalid Entry.  Try again.\n\n\nPlease enter a y for yes or n for no:  ";
				cin.clear();

			}
			if (run == 'y'){
				main();
			}
			else{

			}
			valid_entry = true;

		}
		cin.ignore(10, '\n');
		cout << "\n\nPress enter to exit......";
		cin.get();
		return 0;
	}
